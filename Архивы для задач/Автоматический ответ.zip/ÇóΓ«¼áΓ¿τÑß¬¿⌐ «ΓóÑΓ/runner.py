import os
from static.other.professions import professions

from flask import Flask, render_template, request, redirect
from flask_wtf import FlaskForm
from wtforms import StringField, PasswordField, BooleanField, SubmitField
from wtforms.validators import DataRequired
from flask import Flask, render_template, request, redirect


app = Flask(__name__)


imgFolder = os.path.join('static', 'img')
app.config['SECRET_KEY'] = 'yandexlyceum_secret_key'
#  app.config['UPLOAD_FOLDER'] = imgFolder   -  позже пригодится


user_info = {
}


class LoginForm(FlaskForm):
    username = StringField('Логин', validators=[DataRequired()])
    password = PasswordField('Пароль', validators=[DataRequired()])
    remember_me = BooleanField('Запомнить меня')
    submit = SubmitField('Войти')


@app.route('/', methods=['POST', 'GET'])
def default():
    html_file = 'html/index.html'
    return render_template(html_file,
                           title='Миссия колонизация Марса!',
                           menu_bar_title='Миссия колонизация Марса!',
                           professions=professions)


@app.route('/login', methods=['GET', 'POST'])
def login():
    form = LoginForm()
    if form.validate_on_submit():
        return redirect('/success')
    return render_template('html/login.html', title='Авторизация', form=form)


@app.route('/success', methods=['GET', 'POST'])
def success():
    return 'Вход выполнен'


@app.route('/reg', methods=['POST', 'GET'])
def reg():
    html_file = "html/registration_form.html"
    if request.method == 'GET':
        return render_template(html_file,
                               title='Регистрация',
                               menu_bar_title='Миссия колонизация Марса!',
                               professions=professions)
    elif request.method == 'POST':
        try:
            user_info['surname'] = request.form['surname']
            user_info['name'] = request.form['name']
            user_info['email'] = request.form['email']
            user_info['studying'] = request.form['studying']
            profs = []
            profs.append(request.form['engineer'])
            profs.append(request.form['pilot'])
            profs.append(request.form['builder'])
            profs.append(request.form['coolman'])
            profs.append(request.form['fatman'])
            profs.append(request.form['instagirl'])
            profs.append(request.form['doctor'])
            profs.append(request.form['engineer'])
            user_info['professions'] = profs
            user_info['accept'] = request.form['accept']
            user_info['sex'] = request.form['sex']
            user_info['about'] = request.form['about']
        finally:
            return redirect('/answer')


@app.route('/answer', methods=['POST', 'GET'])
def answer():
    html_file = 'html/auto_answer.html'
    return render_template(html_file,
                           title='Профиль',
                           params=user_info,
                           menu_bar_title='Миссия колонизация Марса!', )


@app.route('/training/<prof>', methods=['POST', 'GET'])
def professions_training(prof):
    if request.method == 'GET':
        html_file = 'html/training_professions.html'
        return render_template(html_file,
                               title=prof,
                               prof=prof,
                               menu_bar_title='Миссия колонизация Марса!',
                               bar_back_href='/list_prof/ol',
                               bar_back_title='←Назад',
                               label_img=f'Мне сложно было найти схемы, так что вот - держите это {prof.lower()}!',
                               prof_about=professions[prof][1],
                               img_link=professions[prof][0],
                               alt=f"Ну тут должен быть {prof}")


@app.route('/list_prof/<list_type>', methods=['POST', 'GET'])
def list_professions(list_type):
    html_file = "html/list_prof.html"
    if list_type == 'ol':
        return render_template(html_file,
                               title='Список профессий',
                               type_list='ol',
                               menu_bar_title='Миссия колонизация Марса!',
                               professions=professions)
    elif list_type == 'ul':
        return render_template(html_file,
                               title='Список профессий',
                               type_list='ul',
                               menu_bar_title='Миссия колонизация Марса!',
                               professions=professions)


if __name__ == '__main__':
    app.run(port=8080, host='127.0.0.1', debug=True)
