import os

from flask import Flask, render_template, request


app = Flask(__name__)


imgFolder = os.path.join('static', 'img')
app.config['SECRET_KEY'] = 'yandexlyceum_secret_key'
#  app.config['UPLOAD_FOLDER'] = imgFolder   -  позже пригодится

professions = {
    'Химик': "https://i.pinimg.com/736x/fc/0e/b7/fc0eb7b15b7302bf77a4892b403a62b3--chemistry-haikyuu-anime.jpg",

    'Врач': "https://i.pinimg.com/736x/69/9a/64/699a648a5039265745870ddafa28976c.jpg",

    'Инженер': "https://i.pinimg.com/originals/00/c7/ba/00c7bada204560a3df62088a7f5af3b0.jpg",

    'Программист': "https://yt3.ggpht.com/a/AATXAJwBM9VkbKEtgjdRXIybkVMbY_-xAYRjJEYdEr8c=s900-c-k-c0xffffffff-no-rj-mo",
}


@app.route('/', methods=['POST', 'GET'])
def default():
    return render_template('html/index.html',
                           menu_bar_title='Миссия колонизация Марса!',
                           professions=professions)


@app.route('/training/<prof>', methods=['POST', 'GET'])
def professions_training(prof):
    html_file = 'html/training_professions.html'
    return render_template(html_file,
                           title=prof,
                           prof=prof,
                           menu_bar_title='←Вернуться на главную',
                           label_img=f'Сложно было найти схемы, так что вот - держите {prof.lower()}а',
                           img_link=professions[prof],
                           alt=f"Ну тут должен быть {prof}")


if __name__ == '__main__':
    app.run(port=8080, host='127.0.0.1', debug=True)
